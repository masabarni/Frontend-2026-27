<script setpásztorfioup>
import { computed } from 'vue';
import {useRoute,RouterLink} from 'vue-router';
const route=useRoute();
const books=[
    {id:1,title:'Az alkimista',author:'Paulo Coelho',description:'Egy plásztorfiú utazása az álmai nyomában.'},
    {id:2,title:'1984',author:'George Orwell',description:'Disztópikus regény a megfigyelésről.'},
];
const book = computed(()=>book.find(b=>b.id===Number(route.params.id)))
</script>

<template>
    <section class="card" v-if="book">
        <h1>{{ book.title }}</h1>
        <h3>{{ book.author}}</h3>
        <p>{{ book.description }}</p>
        <RouterLink to="/books">Vissza</RouterLink>
    </section>
    <section v-else class="card">
        <h1>Könyv nem található</h1>
        <RouterLink to="/books">Vissza</RouterLink>
    </section>
</template>