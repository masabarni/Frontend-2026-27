<template>
    <section class="card">
        <h1>Könyvtár - Kezdőlap</h1>
        <p>Válaszd ki a KÖnyvek menüpontot a katalógus megnyitásához.</p>
    </section>
</template>