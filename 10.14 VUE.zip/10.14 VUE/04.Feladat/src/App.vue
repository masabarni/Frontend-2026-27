<script setup>
import { computed, ref } from 'vue';

const books=ref([]), title=ref(''), author=ref(''), error=ref('')
const valid=computed(()=>title.value.trim().length>=2 && author.value.trim().length>0)
function add(){
  if(!valid.value){
    error.value='A cim legalább 2 karakter, a szerző kötelező.';
    return} error.value='';
    books.value.push({id:Date.now(),title:title.value.trim(),author:author.value.trim()})
}
</script>

<template>
  <p class="muted">04. v-model,submit,validácio</p>
  <h1>Új Könyv</h1>
  <form class="card" @submit.prevent="add">
    <label>
      Cim <input v-model="title">
    </label>
    <label>
      szerző
      <input v-model="author">
    </label>
    <p class="error" v-if="error">{{ error }}</p>
      <button>Hozzáadás</button>
  </form>
  <h2>Könyvek:{{ books.length }}</h2>
  <div class="grid">
    <article v-for="b in books" :key="b.id" class="card">
      <h3>{{ b.title }}</h3>
      <p>{{ b.author }}</p>
    </article>
  </div>
</template>
