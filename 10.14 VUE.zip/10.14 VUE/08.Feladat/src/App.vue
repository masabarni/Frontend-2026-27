<script setup>
import { onMounted,ref } from 'vue';
// import axios from 'axios'
const books=ref([]),
      loading=ref(false),
      error=ref('')

async function load(){
  loading.value=true;
  error.value='';
  try{
    const r = await fetch('http://localhost:3000/books');
    // const r = await axios.get('https://localhost:3000/books');
    if(!r.ok)
  {
    throw Error(`HTTP ${r.status}`)
  }

  books.value=await r.json()
  }catch(e){
    error.value = e.message+'- Ellenőrizd, fut-e a json-server'
  }
  finally{
    loading.value=false
  }
}

onMounted(load)
</script>

<template>
  <p class="muted">08.fetch,async/awiit,onMounted</p>
  <h1>API könyvlista</h1>
  <button @click="load">Ujratöltés</button>
  <p v-if="error" class="error">{{ error }}</p>
  <div class="grid" v-else>
    <article v-for="b in books" :key="b.id" class="card">
      <h2>{{ b.title }}</h2>
      <p>{{ b.author }}</p>
      <p>{{ b.description }}</p>
    </article>
  </div>
</template>