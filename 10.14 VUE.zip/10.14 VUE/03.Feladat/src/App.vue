<script setup>
import HelloWorld from './components/HelloWorld.vue'
import ListaElem from './components/Lista.vue'
</script>

<template>
  <!-- <HelloWorld /> -->
   <ListaElem/>
</template>
