<script setup>
import { ref } from 'vue'
const books = ref([
  { id: 1, title: 'Az alkimista', author: 'Paulo Coelho', cover: '' },
  { id: 2, title: 'A Gyűrűk Ura', author: 'J. R. R. Tolkien', cover: '' },
  { id: 3, title: '1984', author: 'George Orwell', cover: '' }
])
function details(book){alert(`ID: ${book.id} - ${book.title}`)}
</script>

<template>
<p class="muted">03  v-for :key,objektumok,eseményparaméter</p>
<h1>Könyvkatalogus</h1>
<div class="grid">
  <article v-for="book in books" :key="book" class="card">
    <h2>{{ book.title }}</h2><p>{{ book.author }}</p>
    <button @click="details(book)">Részletek</button>
  </article>
</div>
<!-- <div v-for="book in books" :key="book.id">
    {{ book.id }} - {{ book.title }} - {{ book.author }} - {{ book.cover }}
</div> -->
</template>