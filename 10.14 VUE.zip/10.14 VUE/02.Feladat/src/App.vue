<script setup>
import HelloWorld from './components/HelloWorld.vue'
import BookShelf from './components/BookShelf.vue';
</script>

<template>
  <!-- <HelloWorld /> -->
  <BookShelf/>
</template>
