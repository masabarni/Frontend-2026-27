<script setup>
import { ref } from 'vue'
const kolcsonzott = ref(0)
function kolcsonzes() { kolcsonzott.value++ }
function visszahozas() {
  if (kolcsonzott.value > 0) kolcsonzott.value--
}
function nullazas() {kolcsonzott.value = 0}
</script>

<template>
  <h2>Kikölcsönzött: {{ kolcsonzott }}</h2>
  <button @click="kolcsonzes">Kölcsönzés</button>
  <button @click="visszahozas">Visszahozás</button>
  <button @click="nullazas">Nullázás</button>
  <p v-if="kolcsonzott >= 5">Sok könyv van kint!</p>
  <p v-else-if="kolcsonzott >= 1 && kolcsonzott <= 4">1-4 Könyv Van</p>
  <p v-else-if="kolcsonzott == 0">Nincs Könyv kint</p>
</template>