<script setup>
import { computed,ref } from 'vue';
const osszeslatszodik = ref(false);
const q=ref(''),
  books=ref([{id:1,title:'Az alkimista', author:'Paulo Coelho'},
  {id:2,title:'A Gyürük Ura',author:'J.R.R Tolkien'},
  {id:3,title:'1984',author:'George Orwell'},
  {id:4,title:'Abigél',author:'Szabó Magda'}])

const filtered = computed(
  ()=>
  {
    const s = q.value.trim().toLocaleLowerCase('hu');
    return books.value.filter(b=>`${b.title} ${b.author}`.toLocaleLowerCase('hu').includes(s))})

function mindmutat(){
  osszeslatszodik.value = true;
}
</script>

<template>
  <p class="muted">05. computed,filter,includes</p>
  <h1>Könyvkereső cim alapján</h1>
  <input v-model="q" placeholder="Keresés cim alapján">
  <p>{{ filtered.length}} találat</p>
  <button class="button" @click="mindmutat">Összes Mutat</button>
  <p v-if="!filtered.length">Nincs találat</p>
  <div v-if="osszeslatszodik" class="grid">
    <article v-for="b in books" :key="b.id" class="card">
      <h2>{{ b.title }}</h2>
      <p>{{ b.author }}</p>
    </article>
  </div>

  <div v-if="osszeslatszodik" class="grid">
    <article v-for="b in filtered" :key="b.id" class="card">
      <h2>{{ b.title }}</h2>
      <p>{{ b.author }}</p>
    </article>
  </div>
</template>
