<script setup>
defineProps({ book: { type: Object, required: true } })
const emit = defineEmits(['details'])
</script>

<template>
  <article>
    <h3>{{ book.title }}</h3>
    <p>{{ book.author }}</p>
    <button @click="emit('details', book.id)">Részletek</button>
  </article>
</template>
