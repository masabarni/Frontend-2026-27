<template>
    <h1>Masa Barnabás Zsolt</h1>
</template>